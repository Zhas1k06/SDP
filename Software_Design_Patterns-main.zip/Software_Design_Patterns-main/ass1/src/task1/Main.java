package task1;

public class Main {
    public static void main(String[] args) {
        Singleton singleton = Singleton.getInstance();
        Singleton singleton1 = Singleton.getInstance();
        if (singleton == singleton1) {
            System.out.println("THE SAME");
        } else {
            System.out.println("NO, IT'S BAD");
        }
    }
}
