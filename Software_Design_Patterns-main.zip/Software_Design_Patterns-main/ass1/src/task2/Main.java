package task2;

public class Main {
    public static void main(String[] args) {
        int numThreads = 5;
        Thread[] threads = new Thread[numThreads];

        for (int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(() -> {
                Singleton singletonInstance = Singleton.getInstance();
                System.out.println("HASH_CODE: " + singletonInstance.hashCode());
            });
        }

        for (Thread thread : threads) {
            thread.start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
