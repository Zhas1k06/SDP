package task3and4;

public class Main {
    public static void main(String[] args) {
        Product product1 = new Product("Laptop", 800.0, 1);
        Product product2 = new Product("Headphones", 100.0, 2);

        ShoppingCart cart = new ShoppingCart();

        cart.addProduct(product1);
        cart.addProduct(product2);

        System.out.println("Cart Contents:");
        for (Product item : cart.getItems()) {
            System.out.println(item.getName() + " - Price: T" + item.getPrice() +
                    " - Quantity: " + item.getQuantity());
        }

        PaymentStrategy creditCardPayment = new CreditCardPaymentStrategy("1234-5678-9012-3456", "John Doe");
        PaymentStrategy paypalPayment = new PayPalPaymentStrategy("john.doe@example.com");

        cart.checkout(creditCardPayment);
    }
}
