package task3and4;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<Product> items = new ArrayList<>();

    public void addProduct(Product product) {
        items.add(product);
    }

    public double calculateTotalPrice() {
        double totalPrice = 0;
        for (Product item : items) {
            totalPrice += item.getPrice() * item.getQuantity();
        }
        return totalPrice;
    }

    public void checkout(PaymentStrategy paymentStrategy) {
        double totalPrice = calculateTotalPrice();
        paymentStrategy.processPayment(totalPrice);
    }

    public List<Product> getItems() {
        return items;
    }
}
