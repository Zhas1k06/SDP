package task3and4;

public interface PaymentStrategy {
    void processPayment(double amount);
}